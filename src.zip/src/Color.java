
enum Color
{
    BLACK,
    WHITE
}

