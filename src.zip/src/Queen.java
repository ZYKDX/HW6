public class Queen implements ChessPiece {
    private int row;
    private int column;

    private Color color;

    public Queen(int row, int column, Color color) {
        this.row = row;
        this.column = column;
    }

    public int getColumn() {
        return column;
    }

    public int getRow() {
        return row;
    }

    public void setRow(int row) {
        if (row >= 0 && row < 8) {
            this.row = row;
        }
    }

    public void setColumn(int column) {
        if(column >= 0 && column < 8){
            this.column = column;
        }
    }

    public Color getColor(){
        return this.color;
    }

    public boolean canMove(int col, int row) {
        // can move anywhere pending obstacles.
        return (col >= 0 && col < 8) && (row >= 0 && row < 8);
    }

    public boolean canKill(ChessPiece piece){
        if(canMove(piece.getColumn(), piece.getRow()) && (this.color != piece.getColor())){
            return true;
        }
        else{
            return false;
        }
    }
}


